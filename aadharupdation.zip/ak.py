import tkinter as tk
from tkinter import messagebox

class AadhaarForm:
    def __init__(self, root):
        self.root = root
        self.root.title("Aadhaar Updation Form")
        self.root.geometry("500x600")
        self.root.config(bg="#f0f0f0")

        tk.Label(root, text="Aadhaar Updation Form", font=("Arial", 18, "bold"), fg="darkblue", bg="#f0f0f0").pack(pady=20)

        self.fields = {}
        self.create_label_entry("Full Name")
        self.create_label_entry("Aadhaar Number")
        self.create_label_entry("Date of Birth (DD-MM-YYYY)")
        self.create_label_entry("Mobile Number")
        self.create_label_entry("Email")
        self.create_label_entry("Address", height=3)

        # Gender
        gender_frame = tk.Frame(root, bg="#f0f0f0")
        gender_frame.pack(pady=10)
        tk.Label(gender_frame, text="Gender", font=("Arial", 12), bg="#f0f0f0").pack(anchor="w")
        self.gender_var = tk.StringVar()
        for gender in ["Male", "Female", "Other"]:
            tk.Radiobutton(gender_frame, text=gender, variable=self.gender_var, value=gender, bg="#f0f0f0").pack(anchor="w")

        # Buttons
        btn_frame = tk.Frame(root, bg="#f0f0f0")
        btn_frame.pack(pady=20)
        tk.Button(btn_frame, text="Submit", command=self.submit, bg="green", fg="white", width=10).grid(row=0, column=0, padx=10)
        tk.Button(btn_frame, text="Reset", command=self.reset, bg="orange", fg="white", width=10).grid(row=0, column=1, padx=10)

    def create_label_entry(self, label, height=1):
        frame = tk.Frame(self.root, bg="#f0f0f0")
        frame.pack(pady=5, fill="x", padx=20)
        tk.Label(frame, text=label, font=("Arial", 12), bg="#f0f0f0").pack(anchor="w")
        if height > 1:
            entry = tk.Text(frame, height=height, width=40)
        else:
            entry = tk.Entry(frame, width=40)
        entry.pack()
        self.fields[label] = entry

    def submit(self):
        data = {}
        for label, widget in self.fields.items():
            if isinstance(widget, tk.Entry):
                value = widget.get().strip()
            elif isinstance(widget, tk.Text):
                value = widget.get("1.0", tk.END).strip()
            data[label] = value

        data["Gender"] = self.gender_var.get()

        # Basic validation
        if not data["Full Name"] or not data["Aadhaar Number"] or not data["Mobile Number"]:
            messagebox.showerror("Error", "Name, Aadhaar, and Mobile are required.")
            return

        if not data["Aadhaar Number"].isdigit() or len(data["Aadhaar Number"]) != 12:
            messagebox.showerror("Invalid Aadhaar", "Aadhaar number must be 12 digits.")
            return

        if not data["Mobile Number"].isdigit() or len(data["Mobile Number"]) != 10:
            messagebox.showerror("Invalid Mobile", "Mobile number must be 10 digits.")
            return

        # If all checks pass
        messagebox.showinfo("Success", "Details submitted successfully!")
        print("Submitted Data:")
        for k, v in data.items():
            print(f"{k}: {v}")

    def reset(self):
        for widget in self.fields.values():
            if isinstance(widget, tk.Entry):
                widget.delete(0, tk.END)
            elif isinstance(widget, tk.Text):
                widget.delete("1.0", tk.END)
        self.gender_var.set("")

# Run the app
if __name__ == "__main__":
    root = tk.Tk()
    app = AadhaarForm(root)
    root.mainloop()
